<!DOCTYPE html>
<html>
	<head>
		<title>Test home page</title>
	</head>
	<body>
		<p>This was a triumph!</p>
	</body>
</html>
