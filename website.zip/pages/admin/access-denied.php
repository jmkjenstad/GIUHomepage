<?php
// Yes, this is entirely necessary. Shut up.
if (!defined('ADMIN_PAGE_INCLUDED')) die('Access denied');
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Access Denied</title>
  </head>
  <body>
    <div class="error message">
      <h1 class="subject">Access Denied</h1>
      <p class="body">You must be logged in and have permission to access this
      page</p>
    </div>
  </body>
</html>
