<?php
/**
 * Example PHP file.
 */
?>
<html>
  <head>
    <title>Alumnai</title>
  </head>
  <body>
    Example page.
  </body>
</html>
