<?php
$MCSUSER_CONFIG = array(
    'ldap_domain' => '',
    'ldap_hostname' => '',
    'ldap_port' => 0
);
