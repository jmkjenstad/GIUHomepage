<?php


    echo '<p>You must be logged in to view this page!</p>';

?>